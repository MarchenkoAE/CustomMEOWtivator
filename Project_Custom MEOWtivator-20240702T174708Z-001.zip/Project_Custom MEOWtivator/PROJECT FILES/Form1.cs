﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Custom_MEOWtivator
{
    public partial class Form1 : Form
    {
        public WMPLib.WindowsMediaPlayer WMP = new WMPLib.WindowsMediaPlayer();

        public Form1()

        {
            InitializeComponent();
            frm2 = new Form2();
            frm3 = new Form3(this);
            timer1.Interval = 1000;
            timer1.Tick += new EventHandler(timer1_Tick);
            formSet(this, frm2);
        }
        public Form2 frm2;
        public Form3 frm3;


        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < this.listViewAlarm.Items.Count; i++)
            {
                if (((Alarm)this.listViewAlarm.Items[i].Tag).Check())
                {
                    CreateMessage(((Alarm)this.listViewAlarm.Items[i].Tag));
                }
            }
        }
        public void CreateMessage(Alarm alarm)
        {

            if (File.Exists(alarm.MusicFile))
            {
                WMP.URL = alarm.MusicFile;
                WMP.settings.volume = 100;
                WMP.controls.play();
            }
            if (File.Exists(alarm.ImageFile))
            {
                frm3.pictureBox1.Image = new Bitmap(alarm.ImageFile);
            }
            frm3.label1.Text = alarm.Message;
            frm3.frm1 = this;
            frm3.ShowDialog();


        }
        public void StopMusic()
        {
            WMP.controls.stop();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            GlobalSettings.Save();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GlobalSettings.Load();
            if (File.Exists(GlobalSettings.appSettings.AlarmSaveFile))
            {
                LoadAlarm(ref listViewAlarm, GlobalSettings.appSettings.AlarmSaveFile);
            }
        }


        private void pictureBox4_Click(object sender, EventArgs e)
        {
            bool u = selected(ref listViewAlarm);
            if (u == true)
            {
                if (button4.Text == "анг/рус")
                {
                    if (MessageBox.Show("Вы действительно хотите удалить выбранный будильник?", "Внимание", MessageBoxButtons.YesNo,
                           MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        foreach (ListViewItem currentItem in listViewAlarm.SelectedItems)
                        {
                            ((Alarm)currentItem.Tag).IsEnabled = false;
                            currentItem.Remove();
                            frm2.SaveAlarm(ref listViewAlarm, GlobalSettings.appSettings.AlarmSaveFile);
                            break;
                        }
                        if (listViewAlarm.Items.Count < 1)
                        {
                            timer1.Stop();
                        }
                    }
                }
                else
                {
                    if (MessageBox.Show("Are you sure you want to delete selected item?", "Attention", MessageBoxButtons.YesNo,
                           MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        foreach (ListViewItem currentItem in listViewAlarm.SelectedItems)
                        {
                            ((Alarm)currentItem.Tag).IsEnabled = false;
                            currentItem.Remove();
                            frm2.SaveAlarm(ref listViewAlarm, GlobalSettings.appSettings.AlarmSaveFile);
                            break;
                        }
                    }
                    if (listViewAlarm.Items.Count < 1)
                    {
                        timer1.Stop();
                    }
                }
            }
            else
            {
                if (button4.Text == "EN/RU")
                {
                    MessageBox.Show("Please select an item.", "Attention", MessageBoxButtons.OK,
                                  MessageBoxIcon.Exclamation);
                }
                else
                if (button4.Text == "анг/рус")
                {
                    MessageBox.Show("Выберите запись для действия.", "Внимание", MessageBoxButtons.OK,
                                 MessageBoxIcon.Exclamation);
                }
            }
        }



        private void LoadAlarm(ref ListView listViewAlarm, String SavedFile)
        {
            if (!File.Exists(SavedFile))
            {
                return;
            }
            XmlSerializer serializer = new XmlSerializer(typeof(List<Alarm>));
            TextReader textReader = new StreamReader(SavedFile);
            try
            {
                List<Alarm> list = (List<Alarm>)serializer.Deserialize(textReader);
                for (int i = 0; i < list.Count; i++)
                {
                    AddInList(list[i]);
                    {
                        Alarm alarm = list[i];
                    }
                }
            }
            catch (InvalidOperationException)
            {
                textReader.Close();
            }
        }





        public void AddInList(Alarm alarm)
        {
            int index = listViewAlarm.Items.Add(alarm.Message).Index;
            listViewAlarm.Items[index].SubItems.Add(
          alarm.TimeAlarm.ToLongTimeString() + " - " + alarm.TimeAlarm.ToLongDateString());
            if (alarm.IsEnabled == true)
            {
                listViewAlarm.Items[index].Checked = true;
            }
            listViewAlarm.Items[index].Tag = alarm;

        }
        /// <summary>
        /// ---Form2 show---
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = false;
            frm2 = new Form2();
            formSet(this, frm2);
            frm2.Frm1 = this;
            frm2.ShowDialog();
        }
        /// <summary>
        /// ----language section---
        /// </summary>
        /// <param name="frm1"></param>
        /// <param name="frm2"></param>
        void check_lingo(Form1 frm1, Form2 frm2)
        {
            if (frm1.button4.Text == "EN/RU")
            {
                frm1.button4.Text = "анг/рус";
                frm1.listViewAlarm.Columns[1].Text = "Время";
                frm1.listViewAlarm.Columns[0].Text = "Сообщение";
                frm2.label1.Text = "дата | время";
                frm2.label2.Text = "сообщение";
                frm2.label3.Text = "изображение";
                frm2.label4.Text = "муз файл";
                frm2.maskedTextBox2.Text = "*файл не выбран";
                frm2.button1.Text = "нестандарт";
                frm2.button2.Text = "стандарт";
            }
            else
            if (frm1.button4.Text == "анг/рус")
            {
                frm1.button4.Text = "EN/RU";
                frm1.listViewAlarm.Columns[1].Text = "Time";
                frm1.listViewAlarm.Columns[0].Text = "Message";
                frm2.label1.Text = "data | time";
                frm2.label2.Text = "message";
                frm2.label3.Text = "       image";
                frm2.label4.Text = "music file";
                frm2.maskedTextBox2.Text = "*file not chosen";
                frm2.button1.Text = "custom";
                frm2.button2.Text = "preset";
            }
        }
        public void formSet(Form1 frm1, Form2 frm2)
        {
            if (frm1.button4.Text == "анг/рус")
            {
                frm1.button4.Text = "анг/рус";
                frm1.listViewAlarm.Columns[1].Text = "Время";
                frm1.listViewAlarm.Columns[0].Text = "Сообщение";
                frm2.label1.Text = "дата | время";
                frm2.label2.Text = "сообщение";
                frm2.label3.Text = "изображение";
                frm2.label4.Text = "муз файл";
                frm2.maskedTextBox2.Text = "*файл не выбран";
                frm2.button1.Text = "нестандарт";
                frm2.button2.Text = "стандарт";
            }
            else
            if (frm1.button4.Text == "EN/RU")
            {
                frm1.button4.Text = "EN/RU";
                frm1.listViewAlarm.Columns[1].Text = "Time";
                frm1.listViewAlarm.Columns[0].Text = "Message";
                frm2.label1.Text = "data | time";
                frm2.label2.Text = "message";
                frm2.label3.Text = "       image";
                frm2.label4.Text = "music file";
                frm2.maskedTextBox2.Text = "*file not chosen";
                frm2.button1.Text = "custom";
                frm2.button2.Text = "preset";
            }
        }

        public Boolean selected(ref ListView list)
        {
            if (list.SelectedItems.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private void button4_MouseClick(object sender, MouseEventArgs e)
        {
            check_lingo(this, frm2);
        }



        private void pictureBox3_Click(object sender, EventArgs e)
        {
            checkBox1.Checked = true;
            bool u = selected(ref listViewAlarm);
            if (u == true)
            {
                frm2.Frm1 = this;
                frm2.ShowDialog();
            }
            else
            {
                if (button4.Text == "EN/RU")
                {
                    MessageBox.Show("Please select an item.", "Attention", MessageBoxButtons.OK,
                                  MessageBoxIcon.Exclamation);
                }
                else
                if (button4.Text == "анг/рус")
                {
                    MessageBox.Show("Выберите запись для действия.", "Внимание", MessageBoxButtons.OK,
                                 MessageBoxIcon.Exclamation);
                }
            }
        }


    }
}

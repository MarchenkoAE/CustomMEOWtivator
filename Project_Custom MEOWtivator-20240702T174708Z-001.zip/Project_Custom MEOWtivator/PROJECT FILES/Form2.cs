﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;


namespace Custom_MEOWtivator
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            DateTime dateTime = DateTime.Now;
            dateTime = dateTime.AddMinutes(1.0d);
            this.numericUpDownHour.Value = dateTime.Hour;
            this.numericUpDownMinute.Value = dateTime.Minute;
            this.numericUpDownSeconds.Value = 0;
            this.dateTimePicker1.Value = dateTime;
        }

        private Form1 frm1;

        public Form1 Frm1 { get => frm1; set => frm1 = value; }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = String.Empty;
            openDialog.Filter = "Музыкальные файлы|*.mp3; *.mp2; *.wma; *.wav; *.ogg; *.ogm; *.au; *.aif;" +
                            "|Все файлы|*.*";
            if (openDialog.ShowDialog(this) == DialogResult.OK)
            {
                this.maskedTextBox2.Text = openDialog.FileName;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = String.Empty;
            openDialog.Filter = "Image Files (JPG,PNG,GIF)|*.JPG;*.PNG;*.GIF" + "|Все файлы|*.*";
            if (openDialog.ShowDialog(this) == DialogResult.OK)
            {
                pictureBox1.Image = new Bitmap(openDialog.FileName);
                label5.Text = openDialog.FileName;
            }
        }


        public Alarm GetAlarm()
        {
            DateTime date = new DateTime(dateTimePicker1.Value.Year, dateTimePicker1.Value.Month,
                    dateTimePicker1.Value.Day, (int)this.numericUpDownHour.Value, (int)this.numericUpDownMinute.Value, (int)this.numericUpDownSeconds.Value);
            return new Alarm(this.maskedTextBox1.Text,
               this.maskedTextBox2.Text, this.label5.Text, date);
        }

     
        private void button5_Click(object sender, EventArgs e)
        {
            if (Frm1.checkBox1.Checked == false)
            {
                Alarm alarmClock = GetAlarm();
                AddInList(alarmClock);
                SaveAlarm(ref Frm1.listViewAlarm, GlobalSettings.appSettings.AlarmSaveFile);
            }
            else
            {
                foreach (ListViewItem currentItem in Frm1.listViewAlarm.SelectedItems)
                {
                    Alarm alarmClock = GetAlarm();
                    int index = currentItem.Index;
                    Frm1.listViewAlarm.Items[index].SubItems.Add(alarmClock.Message);
                    Frm1.listViewAlarm.Items[index].SubItems.Add(
                        alarmClock.TimeAlarm.ToLongTimeString() + " - " + alarmClock.TimeAlarm.ToLongDateString());
                    Frm1.listViewAlarm.Items[index].Checked = true;
                    Frm1.listViewAlarm.Items[index].Tag = alarmClock;
                    Frm1.listViewAlarm.Items[index].SubItems[1].Text = alarmClock.TimeAlarm.ToLongTimeString() + " - " + alarmClock.TimeAlarm.ToLongDateString();
                    Frm1.listViewAlarm.Items[index].SubItems[0].Text = alarmClock.Message;
                    SaveAlarm(ref Frm1.listViewAlarm, GlobalSettings.appSettings.AlarmSaveFile);
                    Frm1.timer1.Start();
                }
            }

            Frm1.checkBox1.Checked = false;
            this.Close();
        }

        public void AddInList(Alarm alarm)
        {
            int index = Frm1.listViewAlarm.Items.Add(alarm.Message).Index;
            Frm1.listViewAlarm.Items[index].SubItems.Add(alarm.TimeAlarm.ToLongTimeString() + " - " + alarm.TimeAlarm.ToLongDateString());
            Frm1.listViewAlarm.Items[index].Checked = true;
            Frm1.listViewAlarm.Items[index].Tag = alarm;
        }
        public void SaveAlarm(ref ListView listView, String SaveFile)
        {
            Alarm[] TArray = new Alarm[listView.Items.Count];
            for (int i = 0; i < TArray.Length; i++) 
            {
                TArray[i] = (Alarm)listView.Items[i].Tag;
            }

            List<Alarm> list = new List<Alarm>();
            list.Clear();
            for (int i = 0; i < TArray.Length; i++)
            {
                list.Add(TArray[i]);
            }

            XmlSerializer serializer = new XmlSerializer(typeof(List<Alarm>));
            TextWriter textWriter = new StreamWriter(SaveFile);
            serializer.Serialize(textWriter, list);
            textWriter.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm1.timer1.Start();
            Frm1.checkBox1.Checked = false;
            Frm1.frm2 = this;
        }

        private void Form2_Shown(object sender, EventArgs e)
        {
            Frm1.formSet(Frm1, this);
            bool u = Frm1.selected(ref Frm1.listViewAlarm);
            if (Frm1.checkBox1.Checked == true)
            {
                if (u == true)
                {
                    Frm1.checkBox1.Checked = true;
                    foreach (ListViewItem currentItem in Frm1.listViewAlarm.SelectedItems)
                    {
                        Alarm alarm = (Alarm)currentItem.Tag;
                        if (File.Exists(alarm.MusicFile))
                        {
                            maskedTextBox2.Text = alarm.MusicFile;
                        }
                        if (File.Exists(alarm.ImageFile))
                        {
                            pictureBox1.Image = new Bitmap(alarm.ImageFile);
                            label5.Text = alarm.ImageFile;
                        }
                        maskedTextBox1.Text = alarm.Message;
                        DateTime dateTime = alarm.TimeAlarm;
                        numericUpDownHour.Value = dateTime.Hour;
                        numericUpDownMinute.Value = dateTime.Minute;
                        numericUpDownSeconds.Value = 0;
                        dateTimePicker1.Value = dateTime;
                    }
                }
            }
            else
            if (Frm1.checkBox1.Checked == false)
            {
                Alarm alarm = new Alarm();
                maskedTextBox2.Text = "";
                pictureBox1.Image = new Bitmap(Properties.Resources.Illustration7);
                label5.Text = "";
                maskedTextBox1.Text = "";
                DateTime dateTime = alarm.TimeAlarm;
                numericUpDownHour.Value = dateTime.Hour;
                numericUpDownMinute.Value = dateTime.Minute;
                numericUpDownSeconds.Value = 0;
                dateTimePicker1.Value = dateTime;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox4.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
        }
    }
}

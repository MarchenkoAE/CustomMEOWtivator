﻿using System;
using System.IO;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Custom_MEOWtivator
{
    public class AlarmSettings
    {
        public readonly String AlarmSaveFile = Application.StartupPath + "\\newAlarms.xml";

    }
    public class GlobalSettings
    {

        public static AlarmSettings appSettings = new AlarmSettings();

        public static void Save()
        {
            String SettingsFilePath = Application.StartupPath + "\\newSettings.xml";
            XmlSerializer serializer = new XmlSerializer(typeof(AlarmSettings));
            TextWriter textWriter = new StreamWriter(SettingsFilePath);
            serializer.Serialize(textWriter, appSettings);
            textWriter.Close();
        }

        public static Boolean Load()
        {
            String SettingsFilePath = Application.StartupPath + "\\newSettings.xml";
            if (File.Exists(SettingsFilePath))
            {
                XmlSerializer serializer = new XmlSerializer(typeof(AlarmSettings));
                TextReader textReader = new StreamReader(SettingsFilePath);
                appSettings = (AlarmSettings)serializer.Deserialize(textReader);
                textReader.Close();
                return true;
            }
            return false;
        }
    }
}
﻿using System;

namespace Custom_MEOWtivator
{
    public class Alarm
    {
        public String Message { get; set; }
        public String MusicFile { get; set; }
        public String ImageFile { get; set; }
        public DateTime TimeAlarm { get; set; }

        public Boolean IsEnabled { get; set; }

        public Alarm()
        {
            this.Message = String.Empty;
            this.MusicFile = String.Empty;
            this.ImageFile = String.Empty;
            this.TimeAlarm = DateTime.Now;
            IsEnabled = true;
        }

        public Alarm(String Message, String MusicFile, String ImageFile, DateTime TimeAlarm)
        {
            this.Message = Message;
            this.MusicFile = MusicFile;
            this.ImageFile = ImageFile;
            this.TimeAlarm = TimeAlarm;
            IsEnabled = true;
        }




        public Boolean Check()
        {
            if (!IsEnabled)
            {
                return false;
            }

            if (this.TimeAlarm.Year == DateTime.Now.Year &&
                this.TimeAlarm.Month == DateTime.Now.Month &&
                this.TimeAlarm.Day == DateTime.Now.Day &&
                this.TimeAlarm.Hour == DateTime.Now.Hour &&
                this.TimeAlarm.Minute == DateTime.Now.Minute &&
                this.TimeAlarm.Second == DateTime.Now.Second)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }






}

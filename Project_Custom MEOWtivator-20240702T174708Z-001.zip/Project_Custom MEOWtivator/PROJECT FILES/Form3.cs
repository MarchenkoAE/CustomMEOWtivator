﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Custom_MEOWtivator
{
    public partial class Form3 : Form
    {
        public Form3(Form owner)
        {
            this.Owner = owner;
            InitializeComponent();
        }

        public Form1 frm1;


        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.Owner is Form1)
            {
                (this.Owner as Form1).StopMusic();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Shown(object sender, EventArgs e)
        {
            if (pictureBox1.Width > label1.Width)
            {
                Point loc1 = new Point(0, 0);
                pictureBox1.Location = loc1;
                Point loc2 = new Point(pictureBox1.Location.X + ((pictureBox1.Image.Width - label1.Width) / 2), pictureBox1.Location.Y + pictureBox1.Image.Height + 20);
                label1.Location = loc2;
            }
            else
                if (pictureBox1.Width < label1.Width)
            {
                Point loc1 = new Point(0 + ((label1.Width - pictureBox1.Width) / 2), 0);
                pictureBox1.Location = loc1;
                Point loc2 = new Point(0, pictureBox1.Location.Y + pictureBox1.Image.Height + 20);
                label1.Location = loc2;
            }
            else
            {
                Point loc1 = new Point(0, 0);
                pictureBox1.Location = loc1;
                Point loc2 = new Point(0, pictureBox1.Location.Y + pictureBox1.Image.Height + 20);
                label1.Location = loc2;
            }
            this.TopMost = true;
        }

    }
}
